const banner = {
	render: () => {
		return (
            /*html*/`
            <div class="grow px-4 ">
            <img width="1082px" height="382px" src="../../public/images/banner.jpg" alt="">
        </div>
            `
		)
	}
}

export default banner