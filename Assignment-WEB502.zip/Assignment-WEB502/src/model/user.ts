class User {
    email: string;
    phone: string;
    password: string;
    constructor(email: string, phone: string, password: string) {
        this.email = email
        this.phone = phone
        this.password = password
    }
}
export default User