class Category {
    name: string;
    constructor(
        name: string,

    ) {
        this.name = name;

    }
}

export default Category